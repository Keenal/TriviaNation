﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class WelcomeText : MonoBehaviour
{

    public Text displayText;
    public GameObject welcomPanelObject;

    private static WelcomeText welcomText;

    public static WelcomeText Instance()
    {
        if (!welcomText)
        {
            welcomText = FindObjectOfType(typeof(WelcomeText)) as WelcomeText;
            if (!welcomText)
                Debug.LogError("There needs to be one active DisplayManager script on a GameObject in your scene.");
        }

        return welcomText;
    }

    public void DisplayMessage(string message)
    {
        displayText.text = message;
    }

    public void OnMouseDown()
    {
        welcomPanelObject.SetActive(false);
    }
}
