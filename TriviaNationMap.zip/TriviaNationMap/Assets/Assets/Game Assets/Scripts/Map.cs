﻿using UnityEngine;
using System.Data;
using I18N;
using I18N.West;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TriviaNation;
using System;
using UnityEngine.Events;
using TriviaNation.Services;
using TriviaNation.Services.Abstract;
using TriviaNation.Models.Abstract;
using TriviaNation.Models;
using TriviaNation.Repository.Abstract;

namespace TGS
{
	public class Map : Login
    {
        //Unity Specific
        public Texture2D textureForCells;
        public PopUpPanel popUpPanel;
        public DisplayManager displayManager;
        public LeaderBoardPanel leaderBoardPanel;
        public UnityAction trueAction;
        public UnityAction falseAction;
        
        IQuestionEvaluation eval;
        IUser currentUser = user;

        //Territory Specific
        TerrainGridSystem tgs;
        TerrainGridSystem tgsUser;
        TriviaTerritory userTerritory = new TriviaTerritory();
        ITerritoryAdministration territoryAdmin;
        List<TriviaTerritory> listOfUserTerritories;
        private int currentTerritoryIndex { get; set; }
        private bool playersTurn { get; set; }

        IUserTable userTables;
        IUserAdministration userAdministration;

        void Start ()
        {
            new DataBaseOperations();
            DataBaseOperations.ConnectToDB();

            ITriviaAdministration triviaAdmin = new TriviaAdministration();
            IQuestionPack questionPack = triviaAdmin.RetrieveQuestionPackByName("questionPack4");
            eval = new QuestionEvaluation(questionPack);

            // Get a reference to TGS system's API
            tgs = TerrainGridSystem.instance;
            tgsUser = TerrainGridSystem.instance;

            Color32[] colors = textureForCells.GetPixels32();

			int cellCount = tgs.cells.Count;
			for (int k = 0; k < cellCount; k++) {
				Vector2 cellCenter = tgs.cells[k].center;

				int px = (int)((cellCenter.x + 0.5f) * textureForCells.width);

				int py = (int)((cellCenter.y + 0.5f) * textureForCells.height);

				Color32 color = colors[py * textureForCells.width + px];

				tgs.CellToggleRegionSurface(k, true, color);
			}

            tgs.TerritorySetNeutral(1, true);
            tgs.TerritorySetVisible(1, false);

            tgs.OnTerritoryClick += (territoryIndex, buttonIndex) => PopulateQuestion(territoryIndex);

            ITerritoryTable userTerritoryTable = new TerritoryTable();
            ITriviaTerritory userTerritory = new TriviaTerritory();
            territoryAdmin = new TerritoryAdministration(userTerritory, userTerritoryTable);
            listOfUserTerritories = territoryAdmin.ListTerritories();

            SetUserTerritory(listOfUserTerritories);


            userTables = new UserTable();
            userAdministration = new UserAdministration(currentUser, userTables);
            leaderBoardPanel = LeaderBoardPanel.Instance();
            leaderBoardPanel.enabled = true;
            leaderBoardPanel.DisplayUserInformation(userAdministration.BuildUserInfo());
            displayManager = DisplayManager.Instance(); 

            //Checks the territory owners/colors every second 
            InvokeRepeating("UpdateTerritories", 0.0f, 5.0f);
            InvokeRepeating("CheckForTurn", 6.0f, 5.0f);
        } 

        //Populates question from loaded question pack
        void PopulateQuestion(int territoryIndex)
        {
            if (playersTurn && territoryIndex != Convert.ToInt32(userTerritory.territoryIndex) && userTerritory.userName != null)
            {
                currentTerritoryIndex = territoryIndex;
                popUpPanel = PopUpPanel.Instance();
                popUpPanel.enabled = true;
                trueAction = new UnityAction(TrueAnswer);
                falseAction = new UnityAction(FalseAnswer);

                eval.setQuestionInfo();
                popUpPanel.Choice(eval.Question, trueAction, falseAction);
            }
        }

        //Sets user territory if they are logging back in
        public void SetUserTerritory(List<TriviaTerritory> list)
        {
            foreach (TriviaTerritory territory in list)
            {
                if (territory.userName == currentUser.UserName)
                {
                    userTerritory = territory;
                }
            }
            tgsUser.OnTerritoryClick += (territoryIndex, buttonIndex) => AssignTerritory(territoryIndex, userTerritory, list);
        }

        //Assigns territory for user
        public void AssignTerritory(int territoryIndex, TriviaTerritory userTerritory, List<TriviaTerritory> list)
        {
            foreach(TriviaTerritory territory in list)
            {
                if(territory.territoryIndex == territoryIndex.ToString() && userTerritory.territoryIndex == null)
                {
                    displayManager.DisplayMessage("This territory is alread claimed!  Please choose another");
                    return;
                }
            }
            if (userTerritory.territoryIndex == null)
            {
                userTerritory.territoryIndex = territoryIndex.ToString();
                userTerritory.userName = currentUser.UserName;
                userTerritory.color = ConvertColor(tgsUser.territories[territoryIndex].fillColor);
                territoryAdmin.AddTerritory(userTerritory.territoryIndex, userTerritory.userName, userTerritory.color);

                Color newColor;
                ColorUtility.TryParseHtmlString(userTerritory.color, out newColor);
                tgs.TerritoryToggleRegionSurface(territoryIndex, true, newColor);

                displayManager.DisplayMessage("Territory chosen!  Begin your Trivia conquest!");
            }
        }

        //Returns the user's territory
        public TriviaTerritory GetUserTerritory()
        {
            return userTerritory;
        }

        //Action for True Answer
        public void TrueAnswer()
        {
            bool done = false;
            displayManager.DisplayMessage(eval.evaluateAnswer("True"));

            if (eval.Change)
            {
                int userIndex = Convert.ToInt32(GetUserTerritory().territoryIndex);
                if (currentTerritoryIndex != userIndex && eval.Change)
                {
                    Color newColor;
                    ColorUtility.TryParseHtmlString(userTerritory.color, out newColor);
                    tgs.TerritoryToggleRegionSurface(currentTerritoryIndex, true, newColor);

                    foreach (TriviaTerritory territory in listOfUserTerritories)
                    {
                        if (territory.territoryIndex == currentTerritoryIndex.ToString())
                        {
                            territoryAdmin.UpdateUserAndColor(currentTerritoryIndex.ToString(), userTerritory.userName, userTerritory.color);
                            currentUser.Score = userAdministration.UpdateScore(currentUser.UserName, currentUser.Score, eval.PointValue);
                            done = true;
                        }
                    }

                    if (!done)
                    {
                        territoryAdmin.AddTerritory(currentTerritoryIndex.ToString(), userTerritory.userName, userTerritory.color);
                        currentUser.Score = userAdministration.UpdateScore(currentUser.UserName, currentUser.Score, eval.PointValue);
                    }
                }
            }
            else
            {
                currentUser.Score = userAdministration.UpdateScore(currentUser.UserName, currentUser.Score, -10);
            }
            territoryAdmin.DisableTurn(listOfUserTerritories, currentUser.UserName);
        }

        //Action for False Answer
        public void FalseAnswer()
        {
            bool done = false;
            displayManager.DisplayMessage(eval.evaluateAnswer("False"));

            if (eval.Change)
            {
                int userIndex = Convert.ToInt32(GetUserTerritory().territoryIndex);

                if (currentTerritoryIndex != userIndex && eval.Change)
                {
                    Color newColor;
                    ColorUtility.TryParseHtmlString(userTerritory.color, out newColor);
                    tgs.TerritoryToggleRegionSurface(currentTerritoryIndex, true, newColor);

                    foreach (TriviaTerritory territory in listOfUserTerritories)
                    {
                        if (territory.territoryIndex == currentTerritoryIndex.ToString())
                        {
                            territoryAdmin.UpdateUserAndColor(currentTerritoryIndex.ToString(), userTerritory.userName, userTerritory.color);
                            currentUser.Score = userAdministration.UpdateScore(currentUser.UserName, currentUser.Score, eval.PointValue);
                            done = true;
                        }
                    }

                    if (!done)
                    {
                        territoryAdmin.AddTerritory(currentTerritoryIndex.ToString(), userTerritory.userName, userTerritory.color);
                        currentUser.Score = userAdministration.UpdateScore(currentUser.UserName, currentUser.Score, eval.PointValue);
                    }
                }
            }
            else
            {
                currentUser.Score = userAdministration.UpdateScore(currentUser.UserName, currentUser.Score, -10);
            }

            territoryAdmin.DisableTurn(listOfUserTerritories, currentUser.UserName);
        }

        //Converts the color from Color to Hex
        public string ConvertColor(Color color)
        {
            return "#" + ColorUtility.ToHtmlStringRGBA(color);
        }

        //Updates the territory colors
        public void UpdateTerritories()
        {
            listOfUserTerritories = territoryAdmin.ListTerritories();
            foreach (TriviaTerritory territory in listOfUserTerritories)
            {
                Color newColor;
                ColorUtility.TryParseHtmlString(territory.color, out newColor);
                tgs.TerritoryToggleRegionSurface(Convert.ToInt32(territory.territoryIndex), true, newColor);
            }
        }

        public void CheckForTurn()
        {
            playersTurn = territoryAdmin.CheckForTurn(currentUser.UserName);
            if (playersTurn)
                displayManager.DisplayMessage("It's your turn!!!");
            else
                displayManager.DisplayMessage("Waiting on other players...");

        }
        //Refreshes the page
        public void Update()
        {
            if (Input.GetKeyDown(KeyCode.Tab))
            {
                leaderBoardPanel.DisplayUserInformation(userAdministration.BuildUserInfo());
                leaderBoardPanel.leaderBoardPanelObject.SetActive(true);
            }

            if (Input.GetKeyUp(KeyCode.Tab))
                leaderBoardPanel.leaderBoardPanelObject.SetActive(false);
        }
    }
}
