Poly2Tri library adapted for TGS
