﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using System.Collections;
using System;

public class PopUpPanel : MonoBehaviour
{
    public Text question;
    public Image iconImage;
    public Button trueButton;
    public Button falseButton;
    public GameObject popUpPanelObject;

    public static PopUpPanel popUpPanel;

    public static PopUpPanel Instance ()
    {
        if(!popUpPanel)
        {
            popUpPanel = FindObjectOfType(typeof(PopUpPanel)) as PopUpPanel;

            if (!popUpPanel)
                Debug.LogError("there needs to be one active Popup Panel script on a gameObject in your scene");
        }

        return popUpPanel;
    }

    //Yes - No - Cancel
    //Parameters:  A string, a Yes event, a No event, and Cancel event
    public void Choice(string question, UnityAction trueEvent, UnityAction falseEvent)//, UnityAction cancelEvent)
    {
        //Activates the panel
        popUpPanelObject.SetActive(true);
        Debug.Log("PopUpPanel Started\n\n");
        Console.WriteLine("PopUpPanel Started\n\n");
        //Removes all listeners from the button so that when you click it later, it does not
        //call an older function.
        trueButton.onClick.RemoveAllListeners();

        //Add your own listener.
        trueButton.onClick.AddListener(trueEvent);

        //Close the Panel
        trueButton.onClick.AddListener(ClosePanel);

        falseButton.onClick.RemoveAllListeners();
        falseButton.onClick.AddListener(falseEvent);
        falseButton.onClick.AddListener(ClosePanel);

        //cancelButton.onClick.RemoveAllListeners();
        //cancelButton.onClick.AddListener(cancelEvent);
        //cancelButton.onClick.AddListener(ClosePanel);

        this.question.text = question;

        this.iconImage.gameObject.SetActive(false);
        trueButton.gameObject.SetActive(true);
        falseButton.gameObject.SetActive(true);
        //cancelButton.gameObject.SetActive(true);
    }

    //closes the panel
    public void ClosePanel()
    {
        popUpPanelObject.SetActive(false);
    }
}
