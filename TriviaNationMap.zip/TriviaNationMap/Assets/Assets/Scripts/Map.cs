﻿using UnityEngine;
using System.Data;
using I18N;
using I18N.West;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TriviaNation;
using System;
using UnityEngine.Events;

namespace TGS
{
	public class Map : MonoBehaviour
    {
        public Texture2D textureForCells;
        public PopUpPanel popUpPanel;
        public DisplayManager displayManager;
        public UnityAction trueAction;
        public UnityAction falseAction;

        TerrainGridSystem tgs;
        TriviaTerritory userTerritory = new TriviaTerritory();
        QuestionEvaluation eval = new QuestionEvaluation();

        private int currentTerritoryIndex { get; set; }

        void Start ()
        {
            // Get a reference to TGS system's API
            tgs = TerrainGridSystem.instance;

            // Read texture colors
            Color32[] colors = textureForCells.GetPixels32();

			// Iterate cells and picks the corresponding color in the texture
			int cellCount = tgs.cells.Count;
			for (int k = 0; k < cellCount; k++) {
				Vector2 cellCenter = tgs.cells[k].center;

                // Convert the center to texture coordinates
                // The center is in the range of -0.5..0.5, so we add 0.5
                //and multiply by the texture width in pixels to get the X texture coordinate         
				int px = (int)((cellCenter.x + 0.5f) * textureForCells.width);

				// Same for Y
				int py = (int)((cellCenter.y + 0.5f) * textureForCells.height);

				// Now get the color
				Color32 color = colors[py * textureForCells.width + px];

				// And assign it to the cell
				tgs.CellToggleRegionSurface(k, true, color);
			}

            //Makes it so you can't click on it.
            tgs.TerritorySetNeutral(1, true);
            tgs.TerritorySetVisible(1, false);

            //Makes it Clear
            //tgs.TerritoryToggleRegionSurface(1, false, Color.clear);
            //tgs.territories[1].region.surfaceGameObject = null;
            tgs.OnTerritoryClick += (territoryIndex, buttonIndex) => populateQuestion(territoryIndex);
            
            //Connect to the DB
            new DataBaseOperations();
            DataBaseOperations.ConnectToDB();

            IDataBaseTable userTerritoryTable = new TerritoryTable();
            ITriviaTerritory userTerritory = new TriviaTerritory();
            ITerritoryAdministration territoryAdmin = new TerritoryAdministration(userTerritory, userTerritoryTable);
            List<TriviaTerritory> listOfUserTerritories = territoryAdmin.ListTerritories();

            setUserTerritory(listOfUserTerritories);
        } 

        void populateQuestion(int territoryIndex)
        {
            currentTerritoryIndex = territoryIndex;
            popUpPanel = PopUpPanel.Instance();
            popUpPanel.enabled = true;
            displayManager = DisplayManager.Instance();
            trueAction = new UnityAction(TrueAnswer);
            falseAction = new UnityAction(FalseAnswer);

            eval.setQuestionInfo();
            popUpPanel.Choice(eval.Question, trueAction, falseAction);

        }

        public void setUserTerritory(List<TriviaTerritory> list)
        {
            foreach (TriviaTerritory territory in list)
            {
                if (Convert.ToInt32(territory.territoryIndex) == 15)
                {
                    userTerritory = territory;
                }
            }
        }

        public TriviaTerritory GetUserTerritory()
        {
            return userTerritory;
        }

        public void TrueAnswer()
        {
            displayManager.DisplayMessage(eval.evaluateAnswer("True"));

            if(eval.Change)
            {
                int userIndex = Convert.ToInt32(GetUserTerritory().territoryIndex);

                if (currentTerritoryIndex != userIndex && eval.Change)
                    tgs.TerritoryToggleRegionSurface(currentTerritoryIndex, true, Color.blue);
            }
        }

        public void FalseAnswer()
        {
            displayManager.DisplayMessage(eval.evaluateAnswer("False"));

            if (eval.Change)
            {
                int userIndex = Convert.ToInt32(GetUserTerritory().territoryIndex);

                if (currentTerritoryIndex != userIndex && eval.Change)
                    tgs.TerritoryToggleRegionSurface(currentTerritoryIndex, true, Color.blue);
            }
        }
    }
}
