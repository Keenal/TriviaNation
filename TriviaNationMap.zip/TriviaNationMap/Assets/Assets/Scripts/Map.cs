﻿using UnityEngine;
using System.Data;
using I18N;
using I18N.West;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TriviaNation;
using System;

namespace TGS
{
	public class Map : MonoBehaviour
    {
        //public WelcomeText welcomeText;
        public Texture2D textureForCells;
        public WelcomeText welcomeText;
        TerrainGridSystem tgs;


        void Start ()
        {
            // Get a reference to TGS system's API

            tgs = TerrainGridSystem.instance;
            welcomeText = WelcomeText.Instance();
            // Read texture colors
            Color32[] colors = textureForCells.GetPixels32();

			// Iterate cells and picks the corresponding color in the texture
			int cellCount = tgs.cells.Count;
			for (int k=0; k< cellCount; k++) {
				Vector2 cellCenter = tgs.cells[k].center;

                // Convert the center to texture coordinates
                // The center is in the range of -0.5..0.5, so we add 0.5
                //and multiply by the texture width in pixels to get the X texture coordinate

				int px = (int)((cellCenter.x + 0.5f) * textureForCells.width);
				// Same for Y
				int py = (int)((cellCenter.y + 0.5f) * textureForCells.height);

				// Now get the color
				Color32 color = colors[py * textureForCells.width + px];

				// And assign it to the cell
				tgs.CellToggleRegionSurface(k, true, color);
			}
            tgs.TerritorySetVisible(1, false);
            //tgs.TerritorySetNeutral(1, true);
            tgs.TerritoryToggleRegionSurface(1, false, Color.clear);



            new DataBaseOperations();
            DataBaseOperations.ConnectToDB();
            //IDataBaseTable QT = new QuestionTable();
            //QT.CreateTable(QT.TableName, QT.TableCreationString);
            //Debug.Log("The table exists: " + QT.TableExists(QT.TableName));
            //IQuestion question = new Questions();

        //    ITriviaAdministration admin = new TriviaAdministration(question, QT);
        //    admin.AddQuestion("Test", "Yup", "Question Type: MC (Test)");
        //    admin.AddQuestion("Working?", "Affirmitive", "Question Type: T/F (Test)");
        //    admin.AddQuestion("No more objects necessary?", "Fer Shizzle", "Question Type: Matching (Test)");
        //    Debug.Log("The number of rows in this table are: " + QT.RetrieveNumberOfRowsInTable());
        //    string test = admin.ListQuestions();
        //    Debug.Log(test);
        //    Debug.Log("The number of cols in this table are: " + QT.RetriveNumberOfColsInTable());
        //    admin.DeleteQuestion(1);
        //    Debug.Log("The number of rows in this table are now: " + QT.RetrieveNumberOfRowsInTable());
        //    test = admin.ListQuestions();
        //    Debug.Log(test);

        //    ///////////////////
        //    //IDataBaseTable territoryTable = new TerritoryTable();
        //    //Debug.Log("The table exists: {0}", territoryTable.TableExists(territoryTable.TableName));
        //    //ITerritory territory = new Territory();
        //    //ITerritoryAdministration territoryAdmin = new TerritoryAdministration(territory, territoryTable);
        //    //var listTest = territoryAdmin.ListTerritories();
        //    //Debug.Log(listTest);
        //    //Debug.Log("The number of rows in the Territory table are now: {0}", territoryTable.RetrieveNumberOfRowsInTable());

        //    /////////////////
        //    IDataBaseTable UT = new UserTable();
        //    UT.CreateTable(UT.TableName, UT.TableCreationString);
        //    Debug.Log("The table exists: " + UT.TableExists(QT.TableName));
        //    IUser user = new User();
        //    IUserAdministration userAdmin = new UserAdministration(user, UT);
        //    userAdmin.AddUser("Bob", "robert@uwf.edu", "password", "password", "65");
        //    userAdmin.AddUser("Sugar", "rcq1@uwf.edu", "abcd1234", "abcd1234", "107");
        //    test = userAdmin.ListUsers();
        //    Debug.Log(test);
        //    Debug.Log("The number of rows in USER table are now: " + UT.RetrieveNumberOfRowsInTable());

        //    IUserAuthentication validate = new UserAuthentication(UT, user);
        //    Debug.Log("Testing proper user name and password that exists: ");
        //    Boolean isAuthenticated = validate.AuthenticateUser("robert@uwf.edu", "password");
        //    Debug.Log("Authentication is: " + isAuthenticated);

        //    Debug.Log("Testing invalid user name and password that does not exist: ");
        //    isAuthenticated = validate.AuthenticateUser("Bobby", "password");
        //    Debug.Log("Authentication is: " + isAuthenticated);

        //    Debug.Log("Testing invalid confirmation password:");
        //    Boolean flag = userAdmin.AddUser("Phil", "tiger@uwf.edu", "house", "home", "107");
        //    Debug.Log("Password Confirmed? " + flag);
        //    Debug.Log("The number of rows in USER table are now: " + UT.RetrieveNumberOfRowsInTable());
        //    userAdmin.DeleteUser(1);
        //    Debug.Log("The number of rows in USER table are now: " + UT.RetrieveNumberOfRowsInTable());

        //    //////////////

        //    Debug.Log("Testing Trivia Now");
        //    ITrivia trivia = new Trivia(QT, question);
        //    Debug.Log(trivia.GetRandomQuestion());
        //    string answer = Console.ReadLine();
        //    Debug.Log("Your answer is: " + trivia.EvaluateAnswer(answer));
        //    Debug.Log(trivia.GetRandomQuestion());
        //    answer = Console.ReadLine();
        //    Debug.Log("Your answer is: " + trivia.EvaluateAnswer(answer));
        }

    }
}
