﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LeaderBoardPanel : MonoBehaviour
{
    public Text rank;
    public Text userName;
    public Text score;

    public GameObject leaderBoardPanelObject;


    private static LeaderBoardPanel leaderBoardPanel;

    public static LeaderBoardPanel Instance()
    {
        if (!leaderBoardPanel)
        {
            leaderBoardPanel = FindObjectOfType(typeof(LeaderBoardPanel)) as LeaderBoardPanel;
            if (!leaderBoardPanel)
                Debug.LogError("There needs to be one active DisplayManager script on a GameObject in your scene.");
        }

        return leaderBoardPanel;
    }

    public void DisplayUserInformation(IList<string> usersInfo)
    {
        for(int i = 0; i < usersInfo.Count; i = i + 3)
        {
            rank.text += usersInfo[i];
            userName.text += usersInfo[i + 1];
            score.text += usersInfo[i + 2];

            if(i + 3 > usersInfo.Count)
            {
                break;
            }
        }
    }
}
